<form>
	Nombre: 
	<input type="text" />
	
	Apellidos: 
	<input type="text" />
</form>
